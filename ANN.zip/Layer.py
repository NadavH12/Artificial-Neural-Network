import numpy as np
from utils import softmax, logistic,  logistic_prime

class Layer:
    #
    # Constructor:
    # 	takes the number of input neurons, the number of output
    # 	neurons and the type of the activation function
    #
    def __init__(self, input_size, output_size, function_type, save_path):
        self.input_size = input_size
        self.output_size = output_size
        self.function_type = function_type
        self.weights = 0
        self.biases = 0
        self.save_path = save_path

    #
    # activation:
    #   calculate the activation function on input vector z
    def activation(self, z):
        if self.function_type == 'logistic':
            a = logistic(z)
        elif self.function_type == "softmax":
            a = softmax(z)
        else:
            assert "invalid activation function type" == False

        return a

    #
    # activation_prime:
    #   calculate the derivative of the activation function on input vector z
    def activation_prime(self, z):
        if self.function_type == 'logistic':
            a = logistic_prime(z)
        else:
            assert "invalid activation_prime function type" == False

        return a

    #
    # load:
    #	takes the path of a save file and loads the weights and biases
    #	from the path. Weights are loaded from the path + "_weights.npy"
    #	biases are loaded from the path + "_biases.npy"
    #
    def load(self):
        self.weights = np.load(self.save_path + "_weights.npy")
        self.biases = np.load(self.save_path + "_biases.npy")
        assert self.weights.shape == (self.output_size, self.input_size)
        assert self.biases.shape == (self.output_size,)

    #
    # save:
    #	takes the path of a save file and saves the weights and biases
    #	into the path. Weights are saved to the path + "_weights.npy"
    #   biases are saved to the path + "_biases.npy"
    #
    def save(self):
        np.save(self.save_path + "_weights.npy", self.weights)
        np.save(self.save_path + "_biases.npy", self.biases)

    # initialize_random:
    #       initialize weights and biases to random values
    #
    def initialize_random(self):
        self.weights = np.random.randn(self.output_size, self.input_size)
        self.biases = np.random.randn(self.output_size)

    #
    # forward:
    #   take inputs and pass them through layer. Return outputs
    #
    def forward(self, inputs):
        self.inputs = inputs
        assert inputs.shape == (self.input_size,)
        z = np.dot(self.weights, inputs) + self.biases
        self.out = self.activation(z)
        return self.out


    # set_delta:
    #   set the delta for the layer directly (e.g. when we use cross entropy delta
    #   for the top most layer)
    def set_delta(self, delta):
        self.delta = delta

    # calc_delta:
    #   calculate the data for this layer using this and upper layer
    def calc_delta(self, upper_layer):
        self.delta = self.activation_prime(self.out) * np.dot(upper_layer.delta, upper_layer.weights)

    # update_weights:
    #   update weights with learning rate
    def update_weights(self, learning_rate):
        self.weights -= learning_rate * np.outer(self.delta, self.inputs)
        self.biases -= learning_rate * self.delta #for biases, input is 1
