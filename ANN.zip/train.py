import numpy as np
import sys
from utils import get_net

#construct net
net = get_net(sys.argv)
if net == None:
    exit()
net.initialize_random()

#Load images and labels
labels = np.loadtxt("data/training60000_labels.csv",  delimiter=",", dtype=int)
images = np.loadtxt("data/training60000.csv",  delimiter=",", dtype=float)

#train
learning_rate = 0.1
net.print_net()
for j in range(15):
    print("Training pass ", j)
    loss = 0
    error_count = 0
    correct_count = 0

    for i in range(labels.shape[0]):
        image = images[i, :]
        label = labels[i]

        out = net.forward(image)
        # convert from probability vector to digit and check against label
        digit = np.argmax(out)
        correct_count += digit == label
        error_count += digit != label
        loss += net.loss(out, label)

        net.backward(learning_rate, out, label)

    # report results of pass
    print("Total loss ", loss)
    net.report_accuracy(correct_count, error_count)

#save
net.save()
