from Layer import Layer
from utils import cross_entropy_loss, cross_entropy_delta


class net:
    def initialize_random(self):
        for l in self.layers: l.initialize_random()

    def load(self):
        for l in self.layers: l.load()

    def save(self):
        for l in self.layers: l.save()

    def loss(self, out, label):
        return cross_entropy_loss(out, label)

    def forward(self, image):
        z = self.layers[0].forward(image)  # image is input to first layer
        for i in range(1, len(self.layers)):
            z = self.layers[i].forward(z)  # output of layer i is input to layer i-1
        return z

    def backward(self, learning_rate, out, label):
        # calculate deltas
        delta = cross_entropy_delta(out, label)
        self.layers[-1].set_delta(delta)  # delta of last layer is calculated from loss
        for i in range(len(self.layers) - 1, 0, -1):
            self.layers[i - 1].calc_delta(self.layers[i])  # delta of layer i-1 is calculated from layer i

        # update weights
        for l in self.layers: l.update_weights(learning_rate)

    def print_net(self):
        print("Network properties: Input:", self.layers[0].input_size, end=", ")
        for i in range(1, len(self.layers)):
            print("Hidden: ", self.layers[i].input_size, end=", ")
        print("Output: ", self.layers[-1].output_size)

    # print accuracy report
    def report_accuracy(self, correct_count, error_count):
        print("Correct classification:  ", correct_count)
        print("Incorrect classification:  ", error_count)
        accuracy = (float(correct_count) / (correct_count + error_count)) * 100
        print("Accuracy:  ", round(accuracy, 2), "%")

class net1(net):
    def __init__(self):
        self.hidden_layer = Layer(784, 1000, "logistic", "net1_hidden")
        self.output_layer = Layer(1000, 10, "softmax", "net1_output")
        self.layers = (self.hidden_layer, self.output_layer)

class net2(net):
    def __init__(self):
        self.hidden_layer1 = Layer(784, 1000, "logistic", "net2_hidden1")
        self.hidden_layer2 = Layer(1000, 50, "logistic", "net2_hidden2")
        self.output_layer = Layer(50, 10, "softmax", "net2_output")
        self.layers = (self.hidden_layer1, self.hidden_layer2, self.output_layer)
