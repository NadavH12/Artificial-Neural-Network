import numpy as np

# Utility functions

# logistic function
def logistic(x):
    return 1. / (1. + np.exp(-x))

# derivative of logistic function
def logistic_prime(x):
    return x * (1-x)

# softmax
def softmax(x):
    e_x = np.exp(x - np.max(x))
    return e_x / e_x.sum()

# cross entropy delta: z is softmax output, y is bin number
def cross_entropy_delta(z, y):
    delta = z                   # delta is equal to the probability output (we wanted zero)
    delta[y] = -(1-z[y])        # except for the correct (we would have wanted one)
    return delta

# cross entropy loss: z is softmax output, y is bin number
def cross_entropy_loss(z,y):
    return -np.sum(np.log(z[y]))

from net import net1, net2
def get_net(argv):
    if len(argv) == 2:
        if argv[1] == "net1":
            return net1()
        if argv[1] == "net2":
            return net2()

    print("usage:", argv[0], "net1|net2")
    return None
