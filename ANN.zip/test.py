import numpy as np
import sys
from utils import get_net

#construct net
net = get_net(sys.argv)
if net == None:
    exit()
net.load()

#Load images and labels
labels = np.loadtxt("data/testing10000_labels.csv",  delimiter=",", dtype=int)
images = np.loadtxt("data/testing10000.csv",  delimiter=",", dtype=float)

#classify
error_count = 0
correct_count = 0

for i in range(labels.shape[0]):
    image = images[i, :]
    label = labels[i]

    out = net.forward(image)

    # convert from probability vector to digit and check against label
    digit = np.argmax(out)
    correct_count += digit == label
    error_count += digit != label

print("==== Results")
net.print_net()
net.report_accuracy(correct_count, error_count)
